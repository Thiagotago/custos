function Home(){
    return <h1>Página Home</h1>
}

export default Home