function Contato(){
    return <h1>Página Contato</h1>
}

export default Contato