function NovoProjeto(){
    return <h1>Página Novo Projeto</h1>
}

export default NovoProjeto